#!/usr/bin/env python
# -*- coding: utf-8 -*-
import threading
import IMSD_parser
from IMSD_parser import *


SEARCH_SERVER = "!SEARCH_SERVER"
SEARCH_ALL_CONN = "!SEARCH_ALL_CONN"
EXTRACT_FEATURE_FLUX = "!EXTRACT_FEATURE_FLUX"
EXTRACT_FEATURE_CONN = "!EXTRACT_FEATURE_CONN"
EXTRACT_FEATURE_ALL_CONN = "!EXTRACT_FEATURE_ALL_CONN"
CHANGE_IM = "!CHANGE_IM"
EXIT = "!EXIT"


list_command = [SEARCH_SERVER , SEARCH_ALL_CONN, EXTRACT_FEATURE_FLUX, EXTRACT_FEATURE_CONN, EXTRACT_FEATURE_ALL_CONN, CHANGE_IM, EXIT]


def check_arguments():
	if not (len(sys.argv) == 2):
		print(colors.Bold+colors.Red+"Invalid Number of Arguments"+colors.ResetAll)
		print_usage();
		sys.exit()
	check_file(sys.argv[1]);

def check_file(nome_file):
	exists = os.path.isfile(nome_file)
	if not exists:
		print ("Input File '" +nome_file+"' not exist\n")
		print_usage();
		sys.exit()

def print_feature(feature):
	stringa = ""+colors.LightMagenta+"\t* Flow Features *\n\n"
	for label, value in	sorted(feature._flow_dict.items(), key=lambda pair: IMSD_parser.FEATURES.LIST_FLOW_FEATURES_NAME.index(pair[0])):
		stringa += colors.LightCyan+ "\t\t--> "+ str(label) +" = "+colors.DarkGray+str(value)+colors.LightCyan+"\n"
		
	stringa += "\n"+colors.LightMagenta+"\t* Client to Server Features *\n\n"
	for label, value in	sorted(feature._c_to_s_dict.items(), key=lambda pair: IMSD_parser.FEATURES.LIST_CLI_FEATURES_NAME.index(pair[0])):
		stringa += colors.LightCyan+ "\t\t--> "+ str(label) +" = "+colors.DarkGray+str(value)+colors.LightCyan+"\n"
	
	stringa += "\n"+colors.LightMagenta+"\t* Server to Client Features *\n\n"
	for label, value in	sorted(feature._s_to_c_dict.items(), key=lambda pair: IMSD_parser.FEATURES.LIST_SVR_FEATURES_NAME.index(pair[0])):
		stringa += colors.LightCyan+ "\t\t--> "+ str(label) +" = "+colors.DarkGray+str(value)+colors.LightCyan+"\n"
	
	print (stringa)
########################################### BANNERS ###########################################
def print_home_banner():
	print(colors.LightYellow + "-----------------------------------------------------------------------------------" +colors.ResetAll)
	var = colors.LightGray+ '''
██╗███╗   ███╗███████╗██████╗     ██████╗  █████╗ ██████╗ ███████╗███████╗██████╗ 
██║████╗ ████║██╔════╝██╔══██╗    ██╔══██╗██╔══██╗██╔══██╗██╔════╝██╔════╝██╔══██╗
██║██╔████╔██║███████╗██║  ██║    ██████╔╝███████║██████╔╝███████╗█████╗  ██████╔╝
██║██║╚██╔╝██║╚════██║██║  ██║    ██╔═══╝ ██╔══██║██╔══██╗╚════██║██╔══╝  ██╔══██╗
██║██║ ╚═╝ ██║███████║██████╔╝    ██║     ██║  ██║██║  ██║███████║███████╗██║  ██║
╚═╝╚═╝     ╚═╝╚══════╝╚═════╝     ╚═╝     ╚═╝  ╚═╝╚═╝  ╚═╝╚══════╝╚══════╝╚═╝  ╚═╝
                                                                                  '''						
	print(colors.LightGreen + var + colors.ResetAll)
	print(colors.LightYellow + "-----------------------------------------------------------------------------------" +colors.ResetAll)
	print(colors.LightGray + "/////////////////////"+colors.Bold+colors.ResetAll+colors.Yellow+" Dip.Informatica UNISA - @Egidio Giacoia "+colors.LightGray+"/////////////////////" +colors.ResetAll)
	

def print_usage():
	print (colors.Bold+colors.LightCyan+"[+] Usage: python script.py [PATH_PCAP_FILE]"+colors.ResetAll)

def print_list_command():
	print(colors.LightBlue + "----------------------------------------------------------------------------------------------" +colors.ResetAll)
	cmdstr = "Command: "
	for cmd in list_command:
		cmdstr = cmdstr + str(cmd) +" - "
	print(colors.LightYellow+cmdstr+colors.ResetAll)

def print_exit_banner():
	pass

########################################### ACTION ###########################################
class ACTION:

	@staticmethod
	def CHANGE_IM():
		global im_name_choose
		global capture
		global scapy_cap
		
		print(colors.LightCyan+"[+] List of supported Instant Messaging: "+colors.LightMagenta+str(IMSD_parser.Capture.LIST_SUPPORTED_IM)+colors.ResetAll+"\n")
		input_user = raw_input(colors.Magenta+"[+] Choose Instant Messaging: "+colors.ResetAll).strip().upper()
		if input_user == im_name_choose:
			print (colors.LightRed+"\t--> Instant Messaging Just Selected "+colors.ResetAll+"\n")
			return
		if input_user in IMSD_parser.Capture.LIST_SUPPORTED_IM:
			capture = getattr(IMSD_parser, input_user+"_Capture")(scapy_cap)
			im_name_choose = input_user
		else:
			print (colors.LightRed+"\t--> Instant Messaging Not Supported "+colors.ResetAll+"\n")
			return

	@staticmethod
	def SEARCH_SERVER():
		print(colors.LightMagenta+"[+] Searching for IP Address"+colors.ResetAll+"\n")
		capture.search_hosts()
		for host in capture._list_hosts:
			print(colors.LightCyan+"\t--> IP Found: " +colors.LightYellow+str(host._ip_addr)+colors.ResetAll+"\n")
		
		print(colors.LightMagenta+"[+] Searching IP "+im_name_choose+" Server"+colors.ResetAll+"\n")
		print(colors.LightGray+"Wait for WHOIS lookup service (make sure you're connected to the internet)"+colors.ResetAll+"\n")
		capture.search_servers()
		if not capture._list_servers:
			print (colors.LightRed+"\t--> No "+im_name_choose+" Server IP Detected"+colors.ResetAll+"\n")
			return
		else:
			list_servers = "["
			for host in capture._list_servers:
				list_servers += " "+host._ip_addr+" "
			list_servers += "]"
			print(colors.LightCyan+"\t--> "+im_name_choose+" Server IP: "+colors.LightGreen+str(list_servers)+colors.ResetAll+"\n");
	
	@staticmethod
	def SEARCH_ALL_CONN():	
		if not capture._list_servers: 
			ACTION.SEARCH_SERVER()
		print(colors.LightMagenta+"[+] Searching for all CLIENT - "+im_name_choose+"_SERVER connections"+colors.ResetAll+"\n")
		capture.search_connections()
		if not capture._list_connections:
			print (colors.LightRed+"\t--> No CLIENT - "+im_name_choose+"_SERVER Connection Detected"+colors.ResetAll+"\n")
			return
			
		for conn in capture._list_connections:
			print(colors.LightCyan+"\t--> Connection: "+colors.ResetAll+"CLIENT_IP:"+colors.LightYellow+str(conn._client_host._ip_addr)+colors.ResetAll+ " - "+im_name_choose+"_IP:"+colors.LightGreen+str(conn._server_host._ip_addr)+colors.ResetAll+"\n")
			capture.search_connection_flux_TCP(conn)
			if not conn._list_flux:
				print (colors.LightRed+"\t\t --> No packets Find"+colors.ResetAll+"\n")
			else:
				for index, flux in conn._list_flux.items():
					print(colors.LightCyan+"\t\t--> Flux: "+colors.ResetAll+"CLIENT_IP:PORT="+colors.LightYellow+str(flux._ip_client)+":"+str(flux._port_client)+colors.ResetAll+ " - "+im_name_choose+"_IP:PORT="+colors.LightGreen+str(flux._ip_server)+":"+str(flux._port_server)+colors.LightMagenta+" ["+flux._protocol+"]"+colors.ResetAll+"\n")
		
		
	@staticmethod
	def EXTRACT_FEATURE_FLUX():
		if not capture._list_connections: 
			ACTION.SEARCH_ALL_CONN()
		
		if not capture._list_connections:
			return
			
		print(colors.LightMagenta+"[+] Searching Stream"+colors.ResetAll+"\n")
		source_1 = raw_input(colors.Magenta+"[+][+] Insert Client IP:Port: "+colors.ResetAll).strip()
		source_2 = raw_input(colors.Magenta+"[+][+] Insert Server IP:Port "+colors.ResetAll).strip()
		
		if ':' not in source_1 or ':' not in source_2:
			print (colors.LightRed+"\t--> Not a valid IP:Port"+colors.ResetAll+"\n")
			return
		
		ip_addr_1 = source_1.split(":")[0]
		port_1 = source_1.split(":")[1]
		
		ip_addr_2 = source_2.split(":")[0]
		port_2 = source_2.split(":")[1]
		
		conn = capture.get_connection(ip_addr_1, ip_addr_2)
		if conn == None:
			print (colors.LightRed+"\t--> No Connection CLIENT-"+im_name_choose+" Detected "+colors.ResetAll+"\n")
			return
				
		
		flux = capture.get_flux(conn, port_1, port_2, "TCP")
	
		if flux == None:
			print (colors.LightRed+"\t--> No Flux CLIENT-"+im_name_choose+" Detected "+colors.ResetAll+"\n")
			return

		print(colors.LightCyan+"[+][+] List of Supported Tag Object: "+colors.LightMagenta+str(IMSD_parser.FEATURES.LIST_OBJECT)+colors.ResetAll+"\n")
		print ("Type "+colors.LightMagenta+"'?' (UNKNOWN)"+colors.ResetAll+" if you don't know the type of stream.\n")
		tag = raw_input(colors.Magenta+"[+][+] Choose Tag Object Stream: "+colors.ResetAll).strip().upper()
		
		if not tag in IMSD_parser.FEATURES.LIST_OBJECT.values():
			print (colors.LightRed+"\t--> Tag Object Not Supported"+colors.ResetAll+"\n")
			return

		
		try:
			frequency = int(raw_input(colors.Magenta+"[+][+] Choose the frequency (hz) in which to split the flow temporally: "+colors.ResetAll).strip().upper())
		except:
			print (colors.LightRed+"\t--> Not a Valid Number"+colors.ResetAll+"\n")
			return
			
		if not frequency > 0:
			print (colors.LightRed+"\t--> Not a Valid Number"+colors.ResetAll+"\n")
			return
		
		try:
			stride = int(raw_input(colors.Magenta+"[+][+] Choose the stride: "+colors.ResetAll).strip().upper())
		except:
			print (colors.LightRed+"\t--> Not a Valid Number"+colors.ResetAll+"\n")
			return
			
		if not stride > 0:
			print (colors.LightRed+"\t--> Not a Valid Number"+colors.ResetAll+"\n")
			return
		
		
		dict_features = {}
	
		try:
			dict_features = capture.extract_flux_features(flux, frequency, stride, tag)
		except:
			print(colors.LightRed+"\t --> No packets Find"+colors.ResetAll+"\n")
			return
				
		IMSD_parser.FEATURES_CSV_CREATOR.delete_folder(IMSD_parser.FEATURES_CSV_CREATOR.PATH_FOLDER_TMP_FEATURE)
		IMSD_parser.FEATURES_CSV_CREATOR.make_folder(IMSD_parser.FEATURES_CSV_CREATOR.PATH_FOLDER_TMP_FEATURE)
		for connection_index, dict_window in dict_features.items():
			try:
				IMSD_parser.FEATURES_CSV_CREATOR.write_csv_tmp_feature(dict_window)
			except:
				print("I/O Error")
				return
			for window_index, feauture in dict_window.items():
				print(colors.LightCyan+"[+][+] FLUX: "+colors.ResetAll+"CLIENT_IP:PORT="+colors.LightYellow+str(feauture._flux._ip_client)+":"+str(feauture._flux._port_client)+colors.ResetAll+ " - "+im_name_choose+"_IP:PORT="+colors.LightGreen+str(feauture._flux._ip_server)+":"+str(feauture._flux._port_server)+colors.LightMagenta+" ["+feauture._flux._protocol+"]"+colors.ResetAll+"\n")
				print(colors.Bold+colors.ResetAll+colors.LightGray+"Frequency="+str(frequency)+", Stride="+str(stride)+colors.ResetAll);
				print colors.LightRed+"[-----] WINDOW "+ str(window_index)+" [-----]"+colors.ResetAll+"\n"
				print_feature(feauture)
				print colors.LightRed+"[--------------------------------------------]"+colors.ResetAll+"\n"
		print(colors.Bold+colors.ResetAll+colors.Yellow+"See TMP_CAPTURE directory for csv file\nAll files in TMP_CAPTURE will be deleted every time the features are extracted"+colors.ResetAll);	
		
		
		update = raw_input(colors.Magenta+"[+][+] Do you want update DATASET with this features? (y/n): "+colors.ResetAll).strip().upper()
		if not update == "Y":
			print (colors.LightRed+"\t--> DATASET not update"+colors.ResetAll+"\n")
			return
			
		name_file = raw_input(colors.Magenta+"[+][+] Type name file csv DATASET (without extension) : "+colors.ResetAll).strip().upper()
		
		try:
			for connection_index, dict_window in dict_features.items():
				IMSD_parser.FEATURES_CSV_CREATOR.write_csv_dataset(dict_window, name_file)
		except:
			print (colors.LightRed+"\t--> DATASET not update"+colors.ResetAll+"\n")
			return
			
		print (colors.LightRed+"\t--> DATASET update"+colors.ResetAll+"\n")
	
	@staticmethod
	def EXTRACT_FEATURE_CONN():
		if not capture._list_connections: 
			ACTION.SEARCH_ALL_CONN()
		
		if not capture._list_connections:
			return
			
		print(colors.LightMagenta+"[+] Searching Stream"+colors.ResetAll+"\n")
		ip_addr_1 = raw_input(colors.Magenta+"[+][+] Insert Client IP: "+colors.ResetAll).strip()
		ip_addr_2 = raw_input(colors.Magenta+"[+][+] Insert Server IP: "+colors.ResetAll).strip()
		

		connection = capture.get_connection(ip_addr_1, ip_addr_2)
		if connection == None:
			print (colors.LightRed+"\t--> No Connection CLIENT-"+im_name_choose+" Detected "+colors.ResetAll+"\n")
			return
				
		print(colors.LightCyan+"[+][+] List of Supported Tag Object: "+colors.LightMagenta+str(IMSD_parser.FEATURES.LIST_OBJECT)+colors.ResetAll+"\n")
		print ("Type "+colors.LightMagenta+"'?' (UNKNOWN)"+colors.ResetAll+" if you don't know the type of stream.\n")
		tag = raw_input(colors.Magenta+"[+][+] Choose Tag Object Stream: "+colors.ResetAll).strip().upper()

		if not tag in IMSD_parser.FEATURES.LIST_OBJECT.values():
			print (colors.LightRed+"\t--> Tag Object Not Supported"+colors.ResetAll+"\n")
			return

		
		try:
			frequency = int(raw_input(colors.Magenta+"[+][+] Choose the frequency (hz) in which to split the flow temporally: "+colors.ResetAll).strip().upper())
		except:
			print (colors.LightRed+"\t--> Not a Valid Number"+colors.ResetAll+"\n")
			return
			
		if not frequency > 0:
			print (colors.LightRed+"\t--> Not a Valid Number"+colors.ResetAll+"\n")
			return
		
		try:
			stride = int(raw_input(colors.Magenta+"[+][+] Choose the stride: "+colors.ResetAll).strip().upper())
		except:
			print (colors.LightRed+"\t--> Not a Valid Number"+colors.ResetAll+"\n")
			return
			
		if not stride > 0:
			print (colors.LightRed+"\t--> Not a Valid Number"+colors.ResetAll+"\n")
			return
		
		list_features = []
		
		list_features = capture.extract_conn_features(connection, frequency, stride, tag)
		
		if not list_features:
			print (colors.LightRed+"\t --> No packets Find For All Connections"+colors.ResetAll+"\n")
		
		IMSD_parser.FEATURES_CSV_CREATOR.delete_folder(IMSD_parser.FEATURES_CSV_CREATOR.PATH_FOLDER_TMP_FEATURE)
		IMSD_parser.FEATURES_CSV_CREATOR.make_folder(IMSD_parser.FEATURES_CSV_CREATOR.PATH_FOLDER_TMP_FEATURE)
		for item in list_features:
			for connection_index, dict_window in item.items():
				IMSD_parser.FEATURES_CSV_CREATOR.write_csv_tmp_feature(dict_window)
				for window_index, feauture in dict_window.items():
					print(colors.LightCyan+"[+][+] FLUX: "+colors.ResetAll+"CLIENT_IP:PORT="+colors.LightYellow+str(feauture._flux._ip_client)+":"+str(feauture._flux._port_client)+colors.ResetAll+ " - "+im_name_choose+"_IP:PORT="+colors.LightGreen+str(feauture._flux._ip_server)+":"+str(feauture._flux._port_server)+colors.LightMagenta+" ["+feauture._flux._protocol+"]"+colors.ResetAll+"\n")
					print(colors.Bold+colors.ResetAll+colors.LightGray+"Frequency="+str(frequency)+", Stride="+str(stride)+colors.ResetAll);
					print colors.LightRed+"[-----] WINDOW "+ str(window_index)+" [-----]"+colors.ResetAll+"\n"
					print_feature(feauture)
					print colors.LightRed+"[--------------------------------------------]"+colors.ResetAll+"\n"
		print(colors.Bold+colors.ResetAll+colors.Yellow+"See CAPTURE directory for csv file\nAll files in CAPTURE will be deleted every time the features are extracted"+colors.ResetAll)

		update = raw_input(
			colors.Magenta + "[+][+] Do you want update DATASET with this features? (y/n): " + colors.ResetAll).strip().upper()
		if not update == "Y":
			print(colors.LightRed + "\t--> DATASET not update" + colors.ResetAll + "\n")
			return

		name_file = raw_input(
			colors.Magenta + "[+][+] Type name file csv DATASET (without extension) : " + colors.ResetAll).strip().upper()

		try:
			for item in list_features:
				for connection_index, dict_window in item.items():
					IMSD_parser.FEATURES_CSV_CREATOR.write_csv_dataset(dict_window, name_file)
		except:
			print(colors.LightRed + "\t--> DATASET not update" + colors.ResetAll + "\n")
			return

		print(colors.LightRed + "\t--> DATASET update" + colors.ResetAll + "\n")
        
	@staticmethod
	def EXTRACT_FEATURE_ALL_CONN(): 
		
		if not capture._list_connections: 
			ACTION.SEARCH_ALL_CONN()
		
		if not capture._list_connections:
			return
			
		print(colors.LightMagenta+"[+] Searching All Stream"+colors.ResetAll+"\n")

		print(colors.LightCyan + "[+][+] List of Supported Tag Object: " + colors.LightMagenta + str(IMSD_parser.FEATURES.LIST_OBJECT) + colors.ResetAll + "\n")
		print(
			"Type " + colors.LightMagenta + "'?' (UNKNOWN)" + colors.ResetAll + " if you don't know the type of stream.\n")
		tag = raw_input(colors.Magenta + "[+][+] Choose Tag Object Stream: " + colors.ResetAll).strip().upper()

		if not tag in IMSD_parser.FEATURES.LIST_OBJECT.values():
			print(colors.LightRed + "\t--> Tag Object Not Supported" + colors.ResetAll + "\n")
			return
		
		try:
			frequency = int(raw_input(colors.Magenta+"[+][+] Choose the frequency (hz) in which to split the flow temporally: "+colors.ResetAll).strip().upper())
		except:
			print (colors.LightRed+"\t--> Not a Valid Number"+colors.ResetAll+"\n")
			return
			
		if not frequency > 0:
			print (colors.LightRed+"\t--> Not a Valid Number"+colors.ResetAll+"\n")
			return

		try:
			stride = int(raw_input(colors.Magenta+"[+][+] Choose the stride: "+colors.ResetAll).strip().upper())
		except:
			print (colors.LightRed+"\t--> Not a Valid Number"+colors.ResetAll+"\n")
			return
			
		if not stride > 0:
			print (colors.LightRed+"\t--> Not a Valid Number"+colors.ResetAll+"\n")
			return
		
		list_features = []
		
		list_features = capture.extract_all_conn_features(frequency, stride, tag)
		
		if not list_features:
			print (colors.LightRed+"\t --> No packets Find For All Connections"+colors.ResetAll+"\n")
		
		IMSD_parser.FEATURES_CSV_CREATOR.delete_folder(IMSD_parser.FEATURES_CSV_CREATOR.PATH_FOLDER_TMP_FEATURE)
		IMSD_parser.FEATURES_CSV_CREATOR.make_folder(IMSD_parser.FEATURES_CSV_CREATOR.PATH_FOLDER_TMP_FEATURE)
		for item in list_features:
			for connection_index, dict_window in item.items():
				IMSD_parser.FEATURES_CSV_CREATOR.write_csv_tmp_feature(dict_window)
				for window_index, feauture in dict_window.items():
					print(colors.LightCyan+"[+][+] FLUX: "+colors.ResetAll+"CLIENT_IP:PORT="+colors.LightYellow+str(feauture._flux._ip_client)+":"+str(feauture._flux._port_client)+colors.ResetAll+ " - "+im_name_choose+"_IP:PORT="+colors.LightGreen+str(feauture._flux._ip_server)+":"+str(feauture._flux._port_server)+colors.LightMagenta+" ["+feauture._flux._protocol+"]"+colors.ResetAll+"\n")
					print(colors.Bold+colors.ResetAll+colors.LightGray+"Frequency="+str(frequency)+", Stride="+str(stride)+colors.ResetAll);
					print colors.LightRed+"[-----] WINDOW "+ str(window_index)+" [-----]"+colors.ResetAll+"\n"
					print_feature(feauture)
					print colors.LightRed+"[--------------------------------------------]"+colors.ResetAll+"\n"
		print(colors.Bold+colors.ResetAll+colors.Yellow+"See CAPTURE directory for csv file\nAll files in CAPTURE will be deleted every time the features are extracted"+colors.ResetAll);

		update = raw_input(
			colors.Magenta + "[+][+] Do you want update DATASET with this features? (y/n): " + colors.ResetAll).strip().upper()
		if not update == "Y":
			print(colors.LightRed + "\t--> DATASET not update" + colors.ResetAll + "\n")
			return

		name_file = raw_input(
			colors.Magenta + "[+][+] Type name file csv DATASET (without extension) : " + colors.ResetAll).strip().upper()

		try:
			for item in list_features:
				for connection_index, dict_window in item.items():
					IMSD_parser.FEATURES_CSV_CREATOR.write_csv_dataset(dict_window, name_file)
		except:
			print(colors.LightRed + "\t--> DATASET not update" + colors.ResetAll + "\n")
			return

		print(colors.LightRed + "\t--> DATASET update" + colors.ResetAll + "\n")
########################################### SCRIPT ###########################################
def main_script():
	while True:
		print_list_command()
		input_user = raw_input(colors.LightGray+">>"+colors.ResetAll).strip().upper()
		if not input_user in list_command:
			print (colors.LightRed+"Not a valid command\n"+colors.ResetAll)
			continue
		if input_user == EXIT: print_exit_banner(); sys.exit();
		t = threading.Thread(target=getattr(ACTION, input_user[1:].strip().upper())())
			
########################################### CLASS COLORS (GRAPHIC) ###########################################
class colors:
	ResetAll = "\033[0m"

	Bold = "\033[1m"
	Dim = "\033[2m"
	Underlined = "\033[4m"
	Blink = "\033[5m"
	Reverse = "\033[7m"
	Hidden = "\033[8m"
	
	ResetBold = "\033[21m"
	ResetDim = "\033[22m"
	ResetUnderlined = "\033[24m"
	ResetBlink = "\033[25m"
	ResetReverse = "\033[27m"
	ResetHidden = "\033[28m"

	Default = "\033[39m"
	Black = "\033[30m"
	Red = "\033[31m"
	Green = "\033[32m"
	Yellow = "\033[33m"
	Blue = "\033[34m"
	Magenta = "\033[35m"
	Cyan = "\033[36m"
	LightGray = "\033[37m"
	DarkGray = "\033[90m"
	LightRed = "\033[91m"
	LightGreen = "\033[92m"
	LightYellow = "\033[93m"
	LightBlue = "\033[94m"
	LightMagenta = "\033[95m"
	LightCyan = "\033[96m"
	White = "\033[97m"

	BackgroundDefault = "\033[49m"
	BackgroundBlack = "\033[40m"
	BackgroundRed = "\033[41m"
	BackgroundGreen = "\033[42m"
	BackgroundYellow = "\033[43m"
	BackgroundBlue = "\033[44m"
	BackgroundMagenta = "\033[45m"
	BackgroundCyan = "\033[46m"
	BackgroundLightGray = "\033[47m"
	BackgroundDarkGray = "\033[100m"
	BackgroundLightRed = "\033[101m"
	BackgroundLightGreen = "\033[102m"
	BackgroundLightYellow = "\033[103m"
	BackgroundLightBlue = "\033[104m"
	BackgroundLightMagenta = "\033[105m"
	BackgroundLightCyan = "\033[106m"
	BackgroundWhite = "\033[107m"

########################################### MAIN PROGRAM FUNCTION ###########################################
def main():
	global capture
	global im_name_choose
	global scapy_cap
	
	print_home_banner()
	check_arguments()
	scapy_cap = rdpcap(sys.argv[1])
	while True:
		print(colors.LightCyan+"[+] List of supported Instant Messaging: "+colors.LightMagenta+str(IMSD_parser.Capture.LIST_SUPPORTED_IM)+colors.ResetAll+"\n")
		input_user = raw_input(colors.Magenta+"[+] Choose Instant Messaging: "+colors.ResetAll).strip().upper()
		if input_user in IMSD_parser.Capture.LIST_SUPPORTED_IM:
			capture = getattr(IMSD_parser, input_user+"_Capture")(scapy_cap)
			im_name_choose = input_user
			break
		else:
			print (colors.LightRed+"\t--> Instant Messaging Not Supported "+colors.ResetAll+"\n")
	IMSD_parser.FEATURES_CSV_CREATOR.delete_folder(FEATURES_CSV_CREATOR.PATH_FOLDER_TMP_FEATURE);
	IMSD_parser.FEATURES_CSV_CREATOR.make_folder(FEATURES_CSV_CREATOR.PATH_FOLDER_TMP_FEATURE);
	main_script()

########################################### MAIN PYTHON FUNCTION  ########################################### 
if __name__ == "__main__":
	main()