#!/usr/bin/env python
from __future__ import division
from ipwhois import IPWhois
from scapy_ssl_tls.ssl_tls import *
from scapy.all import *
import sys
import os
import csv
import shutil
import math
###########################################	FEATURES FUNCTIONS  ###########################################
class FEATURES:
	
	LIST_FLOW_FEATURES_NAME = ["TAG", "DURATION_TIME", "NUMB_OF_PACKETS", "TOTAL_BYTE", "MIN_BYTE", "MAX_BYTE", "AVG_BYTE"]
	LIST_CLI_FEATURES_NAME = ["CLI_NUMB_OF_PACKETS", "CLI_TOTAL_BYTE", "CLI_MIN_BYTE", "CLI_MAX_BYTE", "CLI_AVG_BYTE"]
	LIST_SVR_FEATURES_NAME = ["SVR_NUMB_OF_PACKETS", "SVR_TOTAL_BYTE", "SVR_MIN_BYTE", "SVR_MAX_BYTE", "SVR_AVG_BYTE"]
	
	IMAGE = "I"
	VIDEO = "V"
	AUDIO = "A"
	FILE = "F"
	UNKNOWN = "?"
	LIST_OBJECT = {"IMAGE": IMAGE, "VIDEO": VIDEO, "AUDIO": AUDIO, "FILE": FILE, "UNKNOWN": UNKNOWN}
	
	@staticmethod
	def DURATION_TIME(list_packets):
		time_first_packet = 0
		time_last_packet = 0
		if len(list_packets) >= 1:
			time_first_packet = list_packets[0].time
			time_last_packet = list_packets[len(list_packets)-1].time
		return time_last_packet - time_first_packet
		
	@staticmethod
	def NUMB_OF_PACKETS(list_packets):
		return len(list_packets)
		
	@staticmethod
	def TOTAL_BYTE(list_packets): 
		total_length = 0
		for pkt in list_packets:
			total_length += len(pkt)
		return total_length
	
	@staticmethod
	def MIN_BYTE(list_packets):
		min_length = 0
		if len(list_packets) >=1 :
			min_length = len(list_packets[0])
		else:
			return 0
		
		for pkt in list_packets:
			if pkt.len < min_length:
				min_length = len(pkt)
	
		return min_length
		
	@staticmethod
	def MAX_BYTE(list_packets):
		max_length = None
		if len(list_packets) >=1 :
			max_length = len(list_packets[0])
		else:
			return 0
			
		for pkt in list_packets:
			if pkt.len > max_length:
				max_length = len(pkt)
		
		return max_length
	
	@staticmethod
	def AVG_BYTE(list_packets): 
		if len(list_packets) == 0:
			return 0
		total_length = FEATURES.TOTAL_BYTE(list_packets)
		return total_length / len(list_packets)
	
	@staticmethod
	def get_list_time_packets(list_packets):
		list_time_packets = []
		time_first_packet = 0
		if len(list_packets) == 0: 
			return list_time_packets
		time_first_packet = list_packets[0].time
		for pkt in list_packets:
			list_time_packets.append(pkt.time - time_first_packet)
		return list_time_packets
	
	@staticmethod
	def get_list_numb_pakets_per_seconds(list_packets):
		list_count_packet_per_sec = []
		i=0
		count = 0
		j = 0
		time_first_packet = 0
		if len(list_packets) >= 1:
			time_first_packet = list_packets[0].time
		duration = get_duration_time(list_packets)
		while i<=int(duration)+1:
			if not j < len(list_packets): 
				break
			if int(list_packets[j].time - time_first_packet) < i+1:
				count = count + 1
				if j == len(list_packets)-1:
					list_count_packet_per_sec.append(count)
				j = j + 1
			else:
				list_count_packet_per_sec.append(count)
				count = 0
				i = i + 1
		return list_count_packet_per_sec

	@staticmethod
	def get_list_length_per_seconds(list_packets):
		list_length_packet_per_sec = []
		i=0
		count = 0
		j = 0
		time_first_packet = 0
		if len(list_packets) >= 1:
			time_first_packet = list_packets[0].time
		duration = get_duration_time(list_packets)
		while i<=int(duration)+1:
			if not j < len(list_packets): 
				break
			if int(list_packets[j].time - time_first_packet) < i+1:
				count = count + len(list_packets[j])
				if j == len(list_packets)-1:
					list_length_packet_per_sec.append(count)
				j = j + 1
			else:
				list_length_packet_per_sec.append(count)
				count = 0
				i = i + 1
			
		return list_length_packet_per_sec
	
	@staticmethod
	def extract_flow_features(flux, list_packets_window = None, tag = "?"):
		if list_packets_window == None:
			list_packets = flux._list_packets
		else:
			list_packets = list_packets_window
		
		list_pack_c_to_s = [ pkt for pkt in list_packets if pkt[IP].src == flux._ip_client ]
		list_pack_s_to_c = [ pkt for pkt in list_packets if pkt[IP].src == flux._ip_server ]
		features = Features_Dict(flux)
		
		dict_flow = {}
		dict_c_to_s = {}
		dict_s_to_c = {}
		
		
		for	feature_name in FEATURES.LIST_FLOW_FEATURES_NAME:
			if feature_name == "TAG":
				if tag in FEATURES.LIST_OBJECT.values():
					dict_flow[feature_name] = tag
				else:
					dict_flow[feature_name] = FEATURES.UNKNOWN
			else:
				dict_flow[feature_name] = getattr(FEATURES, feature_name )(list_packets)
		for feature_name in FEATURES.LIST_CLI_FEATURES_NAME:
			dict_c_to_s[feature_name] = getattr(FEATURES, feature_name[4:] )(list_pack_c_to_s)
		for feature_name in FEATURES.LIST_SVR_FEATURES_NAME:
			dict_s_to_c[feature_name] = getattr(FEATURES, feature_name[4:] )(list_pack_s_to_c)
	
		features._flow_dict = dict_flow
		features._c_to_s_dict = dict_c_to_s
		features._s_to_c_dict = dict_s_to_c
		return features
		
	@staticmethod
	def temporal_extract_features(flux, frequency, stride, tag):
		list_packets = flux._list_packets
		tmp_features_dict = {}
		index_window = 1
		list_packets_window = []
		list_time_pkt = FEATURES.get_list_time_packets(list_packets)
		pkt_count = 0
		first_packet = 0
		while index_window <= math.ceil(len(list_packets)/stride):
			start_time = round(list_time_pkt[(index_window -1)* stride], 6)
			first_packet = list_packets[0].time
			end_time = round(start_time + 1, 6)
			list_packets_window = []
			for index_pkt,time_pkt in enumerate(list_time_pkt[(index_window -1) * stride:]):
				r_time_pkt = round(time_pkt, 6)
				if r_time_pkt <= end_time and r_time_pkt >= start_time:
					if pkt_count < frequency:
						list_packets_window.append(list_packets[((index_window -1) * stride) + index_pkt])
						pkt_count += 1
					else:
						break
				else:
					break
			pkt_count = 0
			stringa=""
			for p in list_packets_window:
				stringa += ""+str(round(p.time - first_packet, 6))+" - "
			feature = FEATURES.extract_flow_features(flux, list_packets_window, tag)
			tmp_features_dict[index_window] = feature
			index_window += 1
		return tmp_features_dict
###########################################	FEATURES_CSV_FILE  ###########################################
class FEATURES_CSV_CREATOR:

	PATH_FOLDER_TMP_FEATURE = "TMP_FEATURE"
	
	@staticmethod
	def make_folder(path_folder):
		if not os.path.isdir(path_folder):
			 os.mkdir(path_folder, 0755)

	@staticmethod
	def delete_folder(path_folder):
		if os.path.isdir(path_folder):
			shutil.rmtree(path_folder)
		
	@staticmethod
	def write_csv_tmp_feature(dict_window):
		try:
			for window_index, feauture in dict_window.items():
				csv_file = FEATURES_CSV_CREATOR.PATH_FOLDER_TMP_FEATURE+"/"+feauture._flux._ip_client+"_"+feauture._flux._port_client+"-"+feauture._flux._ip_server+"_"+feauture._flux._port_server+"-"+feauture._flux._protocol+".csv"
				if os.path.exists(csv_file):
					append_write = 'a'
				else:
					append_write = 'w'
				
				with open(csv_file, append_write) as csvfile:
					writer = csv.DictWriter(csvfile,fieldnames=FEATURES.LIST_FLOW_FEATURES_NAME+FEATURES.LIST_CLI_FEATURES_NAME+FEATURES.LIST_SVR_FEATURES_NAME)
					if append_write == 'w':
						writer.writeheader()
					dict_data = feauture._flow_dict.copy()
					dict_data.update(feauture._c_to_s_dict)
					dict_data.update(feauture._s_to_c_dict)
					writer.writerow(dict_data)
		except IOError:
			raise Error("I/O error")
	
	@staticmethod
	def write_csv_dataset(dict_window, name_file):
		try:
			for window_index, feauture in dict_window.items():
				csv_file = name_file+".csv"
				if os.path.exists(csv_file):
					append_write = 'a'
				else:
					append_write = 'w'
				
				with open(csv_file, append_write) as csvfile:
					writer = csv.DictWriter(csvfile,fieldnames=FEATURES.LIST_FLOW_FEATURES_NAME+FEATURES.LIST_CLI_FEATURES_NAME+FEATURES.LIST_SVR_FEATURES_NAME)
					if append_write == 'w':
						writer.writeheader()
					dict_data = feauture._flow_dict.copy()
					dict_data.update(feauture._c_to_s_dict)
					dict_data.update(feauture._s_to_c_dict)
					writer.writerow(dict_data)
		except IOError:
			raise Error("I/O error")
########################################### CLASS HOST  ###########################################	
class Host():

	def __init__(self, ip_addr):
		self._ip_addr = ip_addr	
########################################### CLASS CONNECTION  ###########################################
class Connection():

	def __init__(self, client_host, server_host):
		self._client_host = client_host
		self._server_host = server_host
		self._list_flux = {}
		
	def is_ip_client(self, ip_addr):
		if ip_addr == str(self._client_host._ip_addr):
			return True
		else:
			return False
			
	def is_ip_server(self, ip_addr):
		if ip_addr == str(self._server_host._ip_addr):
			return True
		else:
			return False
########################################### CLASS FLUX  ###########################################
class Flux():
	def __init__(self, list_packets, connection, port_client, port_server, protocol):
		self._list_packets = list_packets
		self._ip_client = connection._client_host._ip_addr
		self._ip_server = connection._server_host._ip_addr
		self._port_client = port_client
		self._port_server = port_server
		self._protocol = protocol	
########################################### CLASS FEATURES_DICT ###########################################	
class Features_Dict:

	def __init__(self, flux):
		self._flux = flux
		self._flow_dict = {}
		self._c_to_s_dict = {}
		self._s_to_c_dict = {}
	
########################################### CLASS CAPTURE ###########################################
class Capture:
	LIST_SUPPORTED_IM = ["WHATSAPP", "TELEGRAM"]
	
	def __init__(self,capture):
		self._capture = capture
		self._list_hosts = []
		self._list_servers = []
		self._list_client_hosts = [];
		self._list_connections = [];
		self._asn = [];
	
	def is_server(self,ip_indr):
		try:
			obj = IPWhois(ip_indr)
			res = obj.lookup_rdap()
			if res['asn'] in self._asn:
				return True;
			else: 
				return False;
		except:
			return False;
				
	def search_hosts(self):
		if self._list_hosts:
			return
		list_ip = set()
		for pkt in self._capture:
			if IP in pkt:
				list_ip.add(pkt[IP].src)
				list_ip.add(pkt[IP].dst)
	
		for ip_addr in list_ip:
			self._list_hosts.append(Host(ip_addr))
	
	def search_servers(self):
		if self._list_servers:
			return
			
		if not self._list_hosts:
			self.search_hosts()
			
		for host in self._list_hosts:
			if self.is_server(host._ip_addr):
				self._list_servers.append(host);
	
	def search_connections(self):
		if not self._list_servers: 
			self.search_servers()
		
		if self._list_connections:
			return
		
		self._list_client_hosts = [x for x in self._list_hosts if x not in self._list_servers]
		
		for client_host in self._list_client_hosts:
			for server_host in self._list_servers:
				for pkt in self._capture:
					if IP in pkt:
						if pkt[IP].src == client_host._ip_addr and pkt[IP].dst == server_host._ip_addr:
							self._list_connections.append(Connection(client_host, server_host))
							break
						if pkt[IP].src == server_host._ip_addr and pkt[IP].dst == client_host._ip_addr:
							self._list_connections.append(Connection(client_host, server_host))
							break

	def search_connection_flux_TCP(self, connection):
		if not self._list_connections:
			self.search_connections()
			
		if not connection in self._list_connections:
			raise Error("No Connection CLIENT-SERVER Detected")
			return
		
		if connection._list_flux:
			return
			
		ip_client = connection._client_host._ip_addr
		ip_server = connection._server_host._ip_addr
		dict_flux = {}
		for pkt in self._capture:
			if IP in pkt:
				if pkt[IP].proto == 6:
					if pkt[IP].src == ip_client and pkt[IP].dst == ip_server:
						index = ip_client+":"+str(pkt[TCP].sport)+"-"+ip_server+":"+str(pkt[TCP].dport)+"_"+"TCP"
						if index not in dict_flux:
							dict_flux[index] = Flux([], connection, str(pkt[TCP].sport), str(pkt[TCP].dport), "TCP")
							dict_flux[index]._list_packets.append(pkt)
							connection._list_flux = dict_flux
						else:
							flux = self.get_flux(connection, pkt[TCP].sport, pkt[TCP].dport, "TCP")
							flux._list_packets.append(pkt)
					elif pkt[IP].src == ip_server and pkt[IP].dst == ip_client:
						index = ip_client+":"+str(pkt[TCP].dport)+"-"+ip_server+":"+str(pkt[TCP].sport)+"_"+"TCP"
						if index not in dict_flux:
							dict_flux[index] = Flux([], connection, str(pkt[TCP].dport), str(pkt[TCP].sport), "TCP")
							dict_flux[index]._list_packets.append(pkt)
							connection._list_flux = dict_flux
						else:
							flux = self.get_flux(connection, pkt[TCP].dport, pkt[TCP].sport, "TCP")
							flux._list_packets.append(pkt)
		
		connection._list_flux = dict_flux
							
			
	def extract_flux_features(self, flux, frequency = 1, stride = 1, tag = FEATURES.UNKNOWN):
	
		if not flux._list_packets:
			raise Error("No Packets Find")
			return
		
		if not frequency > 0:
			raise Error("Not a Valid Frequency! Must be > 0")
			return
		
		if not stride > 0:
			raise Error("Not a Valid Stride! Must be > 0")
			return

		dict_features = {}
		index_string = flux._ip_client+":"+str(flux._port_client)+"-"+flux._ip_server+":"+str(flux._port_server)+"_"+"TCP"
		dict_features[index_string] = FEATURES.temporal_extract_features(flux, frequency, stride, tag)
		
		return dict_features
	
	def extract_conn_features(self, connection, frequency = 1, stride = 1, tag = FEATURES.UNKNOWN):
		list_features = []
		
		if not frequency > 0:
			raise Error("Not a Valid Number for Frequency! Must be > 0")
			return
		
		if not stride > 0:
			raise Error("Not a Valid Stride! Must be > 0")
			return

		if connection not in self._list_connections:
			raise Error("No Connection CLIENT-SERVER Detected")
			return
		
		for index, flux in connection._list_flux.items():
			dict_features = self.extract_flux_features(flux, frequency, stride, tag)
			list_features.append(dict_features)
			
		return list_features
		
	def extract_all_conn_features(self, frequency = 1, stride = 1, tag = FEATURES.UNKNOWN):
		list_features = []
		
		if not frequency > 0:
			raise Error("Not a Valid Number for Frequency! Must be > 0")
			return
		
		if not stride > 0:
			raise Error("Not a Valid Stride! Must be > 0")
			return

		if not self._list_connections:
			self.search_connections()
		
		for conn in self._list_connections:
			for index, flux in conn._list_flux.items():
				try:
					dict_features = self.extract_flux_features(flux, frequency, stride, tag)
					list_features.append(dict_features)
				except:
					continue
			
		return list_features
	
	def get_connection(self, ip_addr_1, ip_addr_2):
		for connect in self._list_connections:
			if connect.is_ip_client(ip_addr_1) and connect.is_ip_server(ip_addr_2):
				return connect
			if connect.is_ip_client(ip_addr_2) and connect.is_ip_server(ip_addr_1):
				return connect
		return None
	
	def get_flux(self, conn, port_1, port_2, protocol):
		index = conn._client_host._ip_addr+":"+str(port_1)+"-"+conn._server_host._ip_addr+":"+str(port_2)+"_"+protocol
		if index in conn._list_flux:
			return conn._list_flux[index]
		return None
########################################### CLASS WA_CAPTURE ############################################
class WHATSAPP_Capture(Capture):

	def __init__(self,capture):
		self._capture = capture
		self._list_hosts = []
		self._list_servers = []
		self._list_client_hosts = [];
		self._list_connections = [];
		self._asn = ["32934"]
########################################### CLASS TELEGRAM_CAPTURE ############################################
class TELEGRAM_Capture(Capture):

	def __init__(self,capture):
		self._capture = capture
		self._list_hosts = []
		self._list_servers = []
		self._list_client_hosts = [];
		self._list_connections = [];
		self._asn = ["62041", "62014", "59930"] 
########################################### CLASS ERROR (EXCEPTION) ############################################	
class Error(Exception):
  pass